package com.mahalli.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class Product(val id:Int, val name:String, val price:Double)
data class Customer(val id:Int, val name:String, val phone:String)
data class CartLine(val product:Product, val qty:Int)

class MainActivity : ComponentActivity() {
    private val products = mutableStateListOf(
        Product(1, "بيضة", 1.0),
        Product(2, "رز", 10.0),
        Product(3, "زيت", 8.0)
    )
    private val customers = mutableStateListOf<Customer>()
    private var invoiceNo = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MahalliApp() }
    }

    @Composable
    fun MahalliApp() {
        var tab by remember { mutableIntStateOf(0) }
        var search by remember { mutableStateOf("") }
        val cart = remember { mutableStateListOf<CartLine>() }

        MaterialTheme {
            Scaffold(
                topBar = { TopAppBar(title = { Text("محلي") }) },
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(tab==0, {tab=0}, label={Text("البيع")}, icon={Text("🧾")})
                        NavigationBarItem(tab==1, {tab=1}, label={Text("الأصناف")}, icon={Text("📦")})
                        NavigationBarItem(tab==2, {tab=2}, label={Text("العملاء")}, icon={Text("👤")})
                    }
                }
            ) { pad ->
                when(tab) {
                    0 -> SaleScreen(Modifier.padding(pad), search, {search=it}, cart)
                    1 -> ProductsScreen(Modifier.padding(pad))
                    else -> CustomersScreen(Modifier.padding(pad))
                }
            }
        }
    }

    @Composable
    fun SaleScreen(mod:Modifier, search:String, setSearch:(String)->Unit, cart:MutableList<CartLine>) {
        val shown = products.filter { it.name.contains(search, true) }
        val total = cart.sumOf { it.product.price * it.qty }
        Column(mod.fillMaxSize().padding(16.dp)) {
            OutlinedTextField(search, setSearch, Modifier.fillMaxWidth(), label={Text("ابحث عن الصنف")})
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(shown) { p ->
                    Row(Modifier.fillMaxWidth().padding(vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style=MaterialTheme.typography.titleMedium)
                            Text("السعر: ${fmt(p.price)}")
                        }
                        Button(onClick={
                            val i=cart.indexOfFirst{it.product.id==p.id}
                            if(i>=0) cart[i]=cart[i].copy(qty=cart[i].qty+1)
                            else cart.add(CartLine(p,1))
                        }) { Text("+") }
                    }
                }
            }
            if(cart.isNotEmpty()) {
                Text("الأصناف المختارة:", style=MaterialTheme.typography.titleMedium)
                cart.forEach { Text("${it.product.name} × ${it.qty} = ${fmt(it.product.price*it.qty)}") }
                Text("الإجمالي: ${fmt(total)}", style=MaterialTheme.typography.headlineSmall)
                Button(onClick={
                    exportInvoice(cart.toList(), total)
                    cart.clear()
                }, Modifier.fillMaxWidth()) { Text("تصدير الفاتورة ومشاركتها") }
            }
        }
    }

    @Composable
    fun ProductsScreen(mod:Modifier) {
        var name by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }
        Column(mod.fillMaxSize().padding(16.dp)) {
            Text("إدارة الأصناف", style=MaterialTheme.typography.headlineSmall)
            OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("اسم الصنف")})
            OutlinedTextField(price,{price=it},Modifier.fillMaxWidth(),label={Text("سعر البيع")})
            Button(onClick={
                val v=price.toDoubleOrNull()
                if(name.isNotBlank() && v!=null) {
                    products.add(Product((products.maxOfOrNull{it.id}?:0)+1,name,v))
                    name=""; price=""
                }
            }) { Text("إضافة صنف") }
            LazyColumn {
                items(products) { p -> Text("${p.name} — ${fmt(p.price)}", Modifier.padding(8.dp)) }
            }
        }
    }

    @Composable
    fun CustomersScreen(mod:Modifier) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        Column(mod.fillMaxSize().padding(16.dp)) {
            Text("العملاء", style=MaterialTheme.typography.headlineSmall)
            OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("اسم العميل")})
            OutlinedTextField(phone,{phone=it},Modifier.fillMaxWidth(),label={Text("رقم الهاتف")})
            Button(onClick={
                if(name.isNotBlank() && phone.isNotBlank()) {
                    customers.add(Customer((customers.maxOfOrNull{it.id}?:0)+1,name,phone))
                    name=""; phone=""
                }
            }) { Text("حفظ العميل") }
            LazyColumn {
                items(customers) { c -> Text("${c.name} — ${c.phone}", Modifier.padding(8.dp)) }
            }
        }
    }

    private fun fmt(v:Double)=String.format(Locale.US,"%.2f",v)

    private fun exportInvoice(lines:List<CartLine>, total:Double) {
        val bmp=Bitmap.createBitmap(1000,1200,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bmp); canvas.drawColor(android.graphics.Color.WHITE)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.BLACK;textSize=42f}
        paint.typeface=Typeface.DEFAULT_BOLD
        canvas.drawText("محلي",700f,80f,paint)
        paint.typeface=Typeface.DEFAULT
        val now=Date()
        val date=SimpleDateFormat("dd/MM/yyyy",Locale.US).format(now)
        val time=SimpleDateFormat("HH:mm",Locale.US).format(now)
        canvas.drawText("فاتورة رقم: ${invoiceNo++}",600f,145f,paint)
        canvas.drawText("التاريخ: $date",600f,205f,paint)
        canvas.drawText("الوقت: $time",600f,265f,paint)
        var y=350f
        lines.forEach {
            canvas.drawText("${it.product.name} × ${it.qty} = ${fmt(it.product.price*it.qty)}",120f,y,paint)
            y+=65f
        }
        paint.typeface=Typeface.DEFAULT_BOLD
        canvas.drawText("الإجمالي: ${fmt(total)}",500f,y+40f,paint)

        val cache=fileCacheDir
        val file=java.io.File(cache,"invoice_${System.currentTimeMillis()}.png")
        java.io.FileOutputStream(file).use{bmp.compress(Bitmap.CompressFormat.PNG,100,it)}
        val uri=androidx.core.content.FileProvider.getUriForFile(this,"com.mahalli.app.fileprovider",file)
        val intent=Intent(Intent.ACTION_SEND).apply{
            type="image/png"; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent,"إرسال الفاتورة"))
    }
}
